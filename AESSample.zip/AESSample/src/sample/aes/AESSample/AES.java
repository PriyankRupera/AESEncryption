package sample.aes.AESSample;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Encoder;

public class AES {
	public static void main(String[] args) {

		String strDataToEncrypt = new String();
		String strCipherText = new String();
		String strDecryptedText = new String();

		String passPhrase = "MasterKey"; // can be any string
		String saltValue = "UDIDValue"; // can be any string
		int passwordIterations = 100; // can be any number
		String initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
		int keySize = 128; // can be 192 or 128

		try {
			/**
			 * Step 1. Generate an AES key using KeyGenerator Initialize the
			 * keysize to 128 bits (16 bytes)
			 * 
			 */
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			KeySpec spec = new PBEKeySpec(passPhrase.toCharArray(), saltValue.getBytes(), passwordIterations, keySize);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), "AES");

			/**
			 * Step 2. Generate an Initialization Vector (IV) a. Use
			 * SecureRandom to generate random bits The size of the IV matches
			 * the blocksize of the cipher (128 bits for AES) b. Construct the
			 * appropriate IvParameterSpec object for the data to pass to
			 * Cipher's init() method
			 */

			byte[] iv = initVector.getBytes(); // Save the IV bytes or send it
			// in plaintext with the
			// encrypted data so you can
			// decrypt the data later
			// SecureRandom prng = new SecureRandom();
			// prng.nextBytes(iv);

			/**
			 * Step 3. Create a Cipher by specifying the following parameters a.
			 * Algorithm name - here it is AES b. Mode - here it is CBC mode c.
			 * Padding - e.g. PKCS7 or PKCS5
			 */

			Cipher aesCipherForEncryption = Cipher.getInstance("AES/CBC/PKCS5PADDING"); // Must
			// specify
			// the
			// mode
			// explicitly
			// as
			// most
			// JCE
			// providers
			// default
			// to
			// ECB
			// mode!!

			/**
			 * Step 4. Initialize the Cipher for Encryption
			 */

			aesCipherForEncryption.init(Cipher.ENCRYPT_MODE, secret, new IvParameterSpec(iv));

			/**
			 * Step 5. Encrypt the Data a. Declare / Initialize the Data. Here
			 * the data is of type String b. Convert the Input Text to Bytes c.
			 * Encrypt the bytes using doFinal method
			 */
			strDataToEncrypt = "Sample";
			byte[] byteDataToEncrypt = strDataToEncrypt.getBytes();
			byte[] byteCipherText = aesCipherForEncryption.doFinal(byteDataToEncrypt);
			// b64 is done differently on Android
			strCipherText = new BASE64Encoder().encode(byteCipherText);
			System.out.println("Cipher Text generated using AES is " + strCipherText);

			/**
			 * Step 6. Decrypt the Data a. Initialize a new instance of Cipher
			 * for Decryption (normally don't reuse the same object) Be sure to
			 * obtain the same IV bytes for CBC mode. b. Decrypt the cipher
			 * bytes using doFinal method
			 */

			Cipher aesCipherForDecryption = Cipher.getInstance("AES/CBC/PKCS5PADDING"); // Must
			// specify
			// the
			// mode
			// explicitly
			// as
			// most
			// JCE
			// providers
			// default
			// to
			// ECB
			// mode!!

			aesCipherForDecryption.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(iv));
			byte[] byteDecryptedText = aesCipherForDecryption.doFinal(byteCipherText);
			strDecryptedText = new String(byteDecryptedText);
			System.out.println(" Decrypted Text message is " + strDecryptedText);
		}

		catch (NoSuchAlgorithmException noSuchAlgo) {
			System.out.println(" No Such Algorithm exists " + noSuchAlgo);
		}

		catch (NoSuchPaddingException noSuchPad) {
			System.out.println(" No Such Padding exists " + noSuchPad);
		}

		catch (InvalidKeyException invalidKey) {
			System.out.println(" Invalid Key " + invalidKey);
		}

		catch (BadPaddingException badPadding) {
			System.out.println(" Bad Padding " + badPadding);
		}

		catch (IllegalBlockSizeException illegalBlockSize) {
			System.out.println(" Illegal Block Size " + illegalBlockSize);
		}

		catch (InvalidAlgorithmParameterException invalidParam) {
			System.out.println(" Invalid Parameter " + invalidParam);
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}