package sample.aes.AESSample;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionDecryptionAES {
	static Cipher cipher;

	static String passPhrase = "MasterKey";        // can be any string
	static  String saltValue = "UDIDValue";        // can be any string
	static  String hashAlgorithm = "SHA1";             // can be "MD5"
	static  int passwordIterations = 100;                // can be any number
	static String initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
	static  int keySize = 128;                // can be 192 or 128
	private static IvParameterSpec _IVParamSpec = new IvParameterSpec(initVector.getBytes());
	private static String TRANSFORMATION = "AES/CBC/PKCS5Padding";
	public static void main(String[] args) throws Exception {

		byte[] key = (saltValue + passwordIterations + passPhrase).getBytes();
		System.out.println((saltValue + passwordIterations + passPhrase).getBytes().length);

		// Need to pad key for AES
		// TODO: Best way?

		// Generate the secret key specs.
		SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");

		String plainText = "Sample";
		System.out.println("Plain Text Before Encryption: " + plainText);

		String encryptedText = encrypt(plainText, secretKeySpec);
		System.out.println("Encrypted Text After Encryption: " + encryptedText);

		String decryptedText = decrypt(encryptedText, secretKeySpec);
		System.out.println("Decrypted Text After Decryption: " + decryptedText);
	}

	public static String encrypt(String plainText, SecretKey secretKey)
			throws Exception {
		byte[] plainTextByte = plainText.getBytes();
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedByte = cipher.doFinal(plainTextByte);
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedText = encoder.encodeToString(encryptedByte);
		return encryptedText;
	}

	public static String decrypt(String encryptedText, SecretKey secretKey)
			throws Exception {
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] encryptedTextByte = decoder.decode(encryptedText);
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
		String decryptedText = new String(decryptedByte);
		return decryptedText;
	}
}